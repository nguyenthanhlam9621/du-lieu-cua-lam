﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt2._2._5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
           // Console.InputEncoding = Encoding.Unicode;
            Console.WriteLine("Rằm Tháng Giêng\nRằm xuân lồng lộng trăng soi,\nSông xuân nước lẫn màu trời thêm xuân.\nGiữa dòng bàn bạc việc quân\nKhuya về bát ngát trăng ngân đầy thuyền.");
        }
    }
}
