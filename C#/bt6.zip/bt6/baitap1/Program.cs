﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap1
{
    class Program
    {
        static void Main(string[] args)
        {
            int isbn;
            string book, author, publisher;
            do
            {
                Console.WriteLine("\nEnter ISBN: ");
            } while (!int.TryParse(Console.ReadLine(),out isbn));

            Console.WriteLine("\nEnter Book Name:\t");
            book = Console.ReadLine();
            Console.WriteLine("\nEnter Author Name:\t");
            author = Console.ReadLine();
            Console.WriteLine("\nEnter Publisher:\t");
            publisher = Console.ReadLine();

            Book book1 = new Book() { ISBN=isbn,bookname=book,author=author,publisher=publisher};

            Console.WriteLine(book1.GetBookInformation()); 

            Console.ReadKey();
        }
    }
}
