﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap1
{
    public class Book
    {
        public string bookname,author,publisher;
        public int ISBN;

        public Book() { }
        public string GetBookInformation()
        {
            return $"ISBN Number \t Book Name \t Author Name \t Publisher Name \n{ISBN} \t {bookname} \t {author} \t {publisher}";
        }
    }
}
