﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap2
{
    public abstract class Car
    {
        protected decimal Speed;
        protected double RegularPrice;
        protected string Color;

        public Car(decimal speed, double regularPrice, string color)
        {
            Speed = speed;
            RegularPrice = regularPrice;
            Color = color;
        }

        public abstract double GetSalePrice();
        
    }
}
