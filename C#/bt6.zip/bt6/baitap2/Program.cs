﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap2
{
    class MyOwnAutoShop
    {
        static void Main(string[] args)
        {
            Car sedan = new Sedan(100,1000,"den",21);
            Car Ford1 = new Ford(400,2000,"nau",2010,10);
            Car Ford2 = new Ford(600,16000,"do",2010,20);
            Car Truck1 = new Truck(200, 6000, "cam", 2020);
            Car Truck2 = new Truck(300, 18000, "vang", 2000);

            Console.WriteLine($"Get Sale Price of sendan mau den:{sedan.GetSalePrice()}$");
            Console.WriteLine($"Get Sale Price of Ford mau nau :{Ford1.GetSalePrice()}$");
            Console.WriteLine($"Get Sale Price of Ford mau do :{Ford2.GetSalePrice()}$");
            Console.WriteLine($"Get Sale Price of Truck mau cam :{Truck1.GetSalePrice()}$");
            Console.WriteLine($"Get Sale Price of Truck mau vang :{Truck2.GetSalePrice()}$");

            Console.ReadKey();
        }
    }
}
