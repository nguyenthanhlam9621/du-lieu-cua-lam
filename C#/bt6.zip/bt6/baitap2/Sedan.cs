﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap2
{
    public class Sedan : Car
    {
        private int Length;

        public Sedan(decimal speed,double RegularPrice,string Color,int Length) :base(speed, RegularPrice, Color)
        {
            this.Length = Length;
        }

        public override double GetSalePrice()
        {
            double a;
            if (Length > 20)
            {
                a = RegularPrice * 0.95;
            }
            else a = RegularPrice * 0.9;

            return a;
        }
    }
}
