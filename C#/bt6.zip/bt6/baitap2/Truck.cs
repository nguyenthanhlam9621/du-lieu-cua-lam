﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap2
{
    public class Truck:Car
    {
        int Weight;

        public Truck(decimal speed, double RegularPrice, string Color,int Weight) : base(speed, RegularPrice, Color)
        {
            this.Weight = Weight;
        }
        public override double GetSalePrice()
        {
            double a;
            if (Weight > 2000)
            {
                a = RegularPrice * 0.9;
            }
            else a = RegularPrice * 0.8;

            return a;
        }
    }
}
