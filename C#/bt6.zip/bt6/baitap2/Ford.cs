﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap2
{
    public class Ford : Car
    {
        private int Year;
        private int ManufacturerDiscount;

        public Ford(decimal speed, double RegularPrice, string Color, int Year, int ManufacturerDiscount) : base(speed, RegularPrice, Color)
        {
            this.Year = Year;
            this.ManufacturerDiscount = ManufacturerDiscount;
        }
        public override double GetSalePrice()
        {
            return RegularPrice-(RegularPrice * ManufacturerDiscount/100);
        }
    }
}
