﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_tap_2._2._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            for (x = 0; x < 10; x++,System.Console.Write("\n"));
            for (y = 0; y < 10; y++,System.Console.WriteLine("{0}",y));
            //xuong dong 10 lan bien dem la x sau do in ra chi so cua y 
        }
    }
}
