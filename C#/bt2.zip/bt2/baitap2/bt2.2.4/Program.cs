﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bt2._2._4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Xin Chao");
            Console.WriteLine("Tam Biet");
        }
    }
}
