﻿using System;

namespace baitap1
{
    class ManageMember
    {
        private string job;
        private int registrationfee;
        public string Name { get; set; }
        public int age { get; set; }
        public string city { get; set; }

        public void Menu()
        {
            Console.WriteLine("Select your profession:");
            Console.WriteLine("1.\tStudent");
            Console.WriteLine("2.\tTeacher");
            Console.WriteLine("3.\tRetired");
            Console.WriteLine("4.\tOthers");
            int choice;
            do
            {
                Console.WriteLine("Enter your choice: ");
            } while (!int.TryParse(Console.ReadLine(), out choice));

            switch (choice)
            {
                case 1:
                    job = "Student";
                    registrationfee = 1000;
                    break;
                case 2:
                    job = "Teacher";
                    registrationfee = 1400;
                    break;
                case 3:
                    job = "Retired";
                    registrationfee = 1500;
                    break;
                case 4:
                    job = "Others";
                    registrationfee = 2000;
                    break;
            }
        }

        public void Display()
        {
            Console.WriteLine("Name\t\t\tAge\tCity\tProfession\t\tMemership Fee");
            Console.WriteLine("----\t\t\t---\t----\t----------\t\t-------------");
            Console.WriteLine($"{Name}\t{age}\t{city}\t{job}\t\t\t{registrationfee}$");
        }
    }
}
