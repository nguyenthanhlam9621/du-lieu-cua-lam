﻿using System;
using System.Text.RegularExpressions;

namespace baitap1
{
    class Program
    {
        static void Main(string[] args)
        {
            ManageMember manageMember = new ManageMember();
            do
            {
                Console.WriteLine("\nEnter the member name: ");
                manageMember.Name = Console.ReadLine();
            } while (!Regex.IsMatch(manageMember.Name, @"\D{6,40}$"));

            int age;
            do
            {
               
                do
                {
                    Console.WriteLine("\nEnter the age of the member:");

                } while (!int.TryParse(Console.ReadLine(), out age));
                if (age < 6) 
                {
                    Console.WriteLine("TRE KHONG DU TUOI!!!");
                }

            } while (age<=6);


            manageMember.age = age;

            do
            {
                Console.WriteLine("\nEnter the city:");
                manageMember.city = Console.ReadLine();
            } while (!Regex.IsMatch(manageMember.city, @"\D{4,}$"));

            manageMember.Menu();
            manageMember.Display();

            Console.ReadKey();
        }
    }
}
