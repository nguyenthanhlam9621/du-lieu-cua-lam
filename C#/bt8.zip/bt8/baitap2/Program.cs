﻿using System;

namespace baitap2
{
    class Program
    {
        static void Main(string[] args)
        {
            Novel books = new Novel(5);
            books[0] = new Book(1,"sach 1","ma1");
            books[1] = new Book(2,"sach 2","ma2");
            books[2] = new Book(3,"sach 3","ma3");
            books[3] = new Book(4,"sach 4","ma4");
            books[4] = new Book(5,"sach 5","ma5");
            Console.WriteLine("CATEGORY: NOVEL");
            Console.WriteLine("Book ID\t\tBook Name\t\tISBN Number");
            Console.WriteLine("-------\t\t---------\t\t-----------");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(books[i].ToString());
            }

            Console.ReadKey();
        }
    }
}
