﻿namespace baitap2
{
    class Novel
    {
        Book[] books;

        public Novel(int length)
        {
            books = new Book[length];
        }
        public Book this[int index]
        {
            get
            {
                if (index < 0 || index > books.Length)
                {
                    return null;
                }
                else
                    return books[index];

            }
            set
            {
                if (index < 0 || index > books.Length)
                    books[index] = null;
                else books[index] = value;
            }
        }
       
    }
}
