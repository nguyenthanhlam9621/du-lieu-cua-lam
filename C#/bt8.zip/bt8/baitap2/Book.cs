﻿namespace baitap2
{
    class Book
    {
        int ISBN { get; }
        string booktitle { get; }
        string Codebook { get; }
        public Book(int ISBN, string booktitle, string Codebook)
        {
            this.ISBN = ISBN;
            this.booktitle = booktitle;
            this.Codebook = Codebook;
        }

        public string ToString()
        {
            return $"{Codebook}\t\t{booktitle}\t\t\t{ISBN}";
        }
    }
}
