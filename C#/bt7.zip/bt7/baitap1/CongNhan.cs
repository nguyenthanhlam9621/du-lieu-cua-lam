﻿using System;

namespace baitap1
{
    class CongNhan : Person
    {
        private string NgheNghiep;
        private int MucThuNhap;

        
        public override void Nhap()
        {
            Console.WriteLine("Nhap Ten:");
            HoTen = Console.ReadLine();
            Console.WriteLine("Nhap Ngay Sinh dd/MM/yyyy: ");
            NgaySinh = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
            Console.WriteLine("Nhap Que Quan:");
            QueQuan= Console.ReadLine();
            Console.WriteLine("Nhap Nghe Nghiep:");
            NgheNghiep =Console.ReadLine();
            do 
            {
                 Console.WriteLine("Nhap Muc Thu Nhap:");

            } while (!int.TryParse(Console.ReadLine(),out MucThuNhap));
           
           
            
        } 

        public override void In()
        {
            Console.WriteLine($"Ho ten: {HoTen}\tNgay Sinh: {NgaySinh.ToString("dd/MM/yyyy")}\tQue Quan: {QueQuan}\tNghe Nghiep: {NgheNghiep}\tThu nhap: {MucThuNhap}");
        }
    }
}
