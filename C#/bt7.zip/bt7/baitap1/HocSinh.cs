﻿using System;

namespace baitap1
{
    class HocSinh : Person
    {
        private string tenLop;
        private float diemTrungBinh;

        public override void Nhap()
        {
            Console.WriteLine("Nhap Ten:");
            HoTen = Console.ReadLine();
            Console.WriteLine("Nhap Ngay Sinh dd/MM/yyyy: ");
            NgaySinh = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
            Console.WriteLine("Nhap Que Quan:");
            QueQuan = Console.ReadLine();
            Console.WriteLine("Nhap ten Lop:");
            tenLop = Console.ReadLine();
            do
            {
                Console.WriteLine("Nhap Diem Trung Binh:");

            } while (!float.TryParse(Console.ReadLine(),out diemTrungBinh));



        }
        public override void In()
        {
            Console.WriteLine($"Ho ten: {HoTen}\tNgay Sinh: {NgaySinh.ToString("dd/MM/yyyy")}\tQue Quan: {QueQuan}\tTen lop: {tenLop}\tDiem trung Binh: {diemTrungBinh}");
        }
    }
}
