﻿using System;

namespace baitap1
{
    abstract class Person
    {
        private string hoTen;
        private DateTime ngaySinh;
        private string queQuan;

        public string HoTen
        {
            get
            {
                return hoTen;
            }
            set
            {
                hoTen = value;
            }
        }
        public DateTime NgaySinh
        {
            get
            {
                return ngaySinh;
            }
            set
            {
                ngaySinh = value;
            }
        }
        public String QueQuan
        {
            get
            {
                return queQuan;
            }
            set
            {
                queQuan = value;
            }
        }
        public abstract void Nhap();
        public abstract void In();
    }
}
