﻿using System;
using System.Collections.Generic;

namespace baitap1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> persons = new List<Person>();
            CongNhan congNhan = new CongNhan();
            HocSinh hocsinh = new HocSinh();

            congNhan.Nhap();
            persons.Add(congNhan);
            hocsinh.Nhap();
            persons.Add(hocsinh);

            foreach (var person in persons)
            {
                Console.WriteLine("Cong nhan:\n");
                if (person is CongNhan)
                {
                    person.In();
                }
                
            }
            foreach (var person in persons)
            {
                Console.WriteLine("Hoc Sinh:\n");
                if (person is HocSinh)
                {
                    person.In();
                }

            }

            Console.ReadKey();
        }
    }
}
