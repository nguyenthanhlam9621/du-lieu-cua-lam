﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_tap_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Hinh h1 = new HinhVuong() { Canh = 10f };
            Console.WriteLine($"Dien tich hinh vuong la : {h1.getArea()}");
            Hinh h2 = new HinhTamGiac() { Day = 10f, CCao = 20f };
            Console.WriteLine($"Dien tich hinh tam giac la: {h2.getArea()}");

            Console.ReadKey();
        }
    }
}
