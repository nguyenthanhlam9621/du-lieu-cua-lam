﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_tap_2
{
    abstract class Hinh
    {
        abstract public float getArea();
    }
}
