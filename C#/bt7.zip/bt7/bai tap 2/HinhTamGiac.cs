﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai_tap_2
{
    class HinhTamGiac:Hinh
    {
        public float Day { get; set; }
        public float CCao { get; set; }
        public override float getArea()
        {
            return (Day* CCao )/2;
        }
    }
}
