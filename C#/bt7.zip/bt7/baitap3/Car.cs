﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap3
{
    class Car : ICar
    {
        public string Name { get; set; }
        public string Producer { get; set; }
        public int Year { get; set; }
        public int Seat { get; set; }
        public float RootPrice { get; set; }

        public float calculateTax()
        {
            float tax;
            if (Seat < 7)
            {
                tax = RootPrice * 60 / 100;
            }
            else
            {
                tax = RootPrice * 70 / 100;
            }
            return tax;
        }
        public virtual float calculatePrice()
        {
            return RootPrice + calculateTax();
        }
        public void getInfor()
        {
            Console.WriteLine($"{Name} car produced by {Producer} in {Year} has {Seat} seats" +
                $"with the total price is {calculatePrice()}$");
        }
    }
}
