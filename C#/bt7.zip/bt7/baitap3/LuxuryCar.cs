﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baitap3
{
    class LuxuryCar:Car
    {
        public float specialRate = 80 / 100;
        public float SpecialRate
        {
            get { return specialRate; }
            set { specialRate = value; }
        }
        public override float calculatePrice()
        {
            return RootPrice + calculateTax() + RootPrice * specialRate;
        }
        public float calculatePrice(float transportCost)
        {
            return RootPrice + calculateTax() + RootPrice * specialRate + transportCost;
        }
    }
}
