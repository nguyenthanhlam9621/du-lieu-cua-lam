﻿using System;

namespace Bai2
{
    class StringManagement
    {
        public string str1;
        public string str2;
        int check=0;
        public int indexchuoi= -1;
        public void Input()
        {
            Console.WriteLine("Enter a string: ");
            str1 = Console.ReadLine();
            Console.WriteLine("Enter a word to search:");
            str2 = Console.ReadLine();
        }
        public void CheckString() 
        {
            
            while (check != -1) 
            {
                check = str1.IndexOf(str2, check + 1);
                indexchuoi += 1;
            }
        }
    }
}
