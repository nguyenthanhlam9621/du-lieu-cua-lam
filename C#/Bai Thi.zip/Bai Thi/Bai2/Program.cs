﻿using System;

namespace Bai2
{
    class Program
    {
        static void Main(string[] args)
        {
            StringManagement stringManagement = new StringManagement();
            stringManagement.Input();
            stringManagement.CheckString();

            Console.WriteLine($"word found {stringManagement.indexchuoi} time in the string");
            Console.ReadKey();
        }
    }
}
