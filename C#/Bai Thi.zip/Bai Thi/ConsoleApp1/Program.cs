﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            People people = new People {Name="Marry",Gender=true,Age=25};
            Console.WriteLine("Simple Properties Demo");
            Console.WriteLine($"Person details: Name={people.Name}, Gender={people.Genden()}, Age={people.Age}");
            people.UpAge();
            Console.WriteLine($"Person details(apter incrementing age): Name={people.Name}, Gender={people.Genden()}, Age={people.Age}");
            Console.ReadKey();

        }
    }
}
