﻿namespace ConsoleApp1
{
    class People
    {
        public string Name { get; set; }
        public bool Gender { get; set; }
        public int Age { get; set; }

        public string gender;
        public void UpAge() 
        {
            Age += 10;
        }
        public string Genden()
        {
            if (Gender == true)
            {
                gender = "Male";
            }
            else 
            {
                gender = "Female";
            }
            return gender;
        }
    }
}
