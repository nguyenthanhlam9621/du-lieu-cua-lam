﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bai1
{
    class Program
    {
        static void Main(string[] args)
        {
            Window[] windows = new Window[3] { new ListBox(20, 30, "binh luan list 1"), new ListBox(20, 30, "con ten list 2"), new Button(30, 20) };
            for (int i = 0; i < windows.Length; i++)
            {
                windows[i].DrawWindow();
            }
            Console.ReadKey();
        }
    }
}
