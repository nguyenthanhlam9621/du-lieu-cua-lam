<?php
//   chua chay duoc la sao chan
   if (isset($_GET["title"]) && !empty(trim($_GET["title"]))){
	  
	  require_once 'includes/config.php';
	  
	  
	  $sql="SELECT * FROM library WHERE title=?";
	  
	  if ($stmt= mysqli_prepare($conn,$sql)){
		
		 mysqli_stmt_bind_param($stmt,"i",$body_title);
		 
		 
		 $body_title=trim($_GET["title"]);
		 
		 
		 if (mysqli_stmt_execute($stmt)){
			$result=mysqli_stmt_get_result($stmt);
			
			if (mysqli_num_rows($result)==1){
			   
			   $row= mysqli_fetch_array($result,MYSQLI_ASSOC);
			   
			   
			   $bookid= $row["bookid"];
			   $authorid= $row["authorid"];
			   $title =$row["title"];
			   $ISBN =$row["ISBN"];
			   $pub_year =$row["pub_year"];
			   $available =$row["available"];
			}else{
			   echo "loiroi";
			   exit();
			}
			
		 }else{
			echo "Oops! Something went wrong. Please try again later.";
		 }
	  }
	  
	 
	  mysqli_stmt_close($stmt);
	  
	  
	  mysqli_close($conn);
   }else{
	  
	  echo "loi";
	  exit();
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Search</title>
   <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
   <style type="text/css">
       .wrapper{
           width: 500px;
           margin:0 auto;
       }
   </style>
</head>
<body>
<div class="wrapper">
   <div class="container-fluid">
	  <div class="row">
		 <div class="col-md-12">
			<div class="page-header">
			   <h1>Search</h1>
			</div>
			<div class="from-group">
			   <label>BookID</label>
			   <p class="form-control-static"><?php echo $row["bookid"];?></p>
			</div>
			<div class="from-group">
			   <label>Authorid</label>
			   <p class="form-control-static"><?php echo $row["authorid"];?></p>
			</div>
			<div class="from-group">
			   <label>Title</label>
			   <p class="form-control-static"><?php echo $row["title"];?></p>
			</div>
			<div class="from-group">
			   <label>ISBN</label>
			   <p class="form-control-static"><?php echo $row["ISBN"];?></p>
			</div>
			<div class="from-group">
			   <label>Pub_year</label>
			   <p class="form-control-static"><?php echo $row["pub_year"];?></p>
			</div>
			<div class="from-group">
			   <label>Available</label>
			   <p class="form-control-static"><?php echo $row["available"];?></p>
			</div>
			<p><a href="index.php" class="btn btn-primary">Back</a></p>
		 </div>
	  </div>
   </div>
</div>
</body>
</html>
