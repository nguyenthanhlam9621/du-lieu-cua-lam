<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Dashboard</title>
   <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
   <script src="http://ajax.goofleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
   <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
   <style type="text/css">
       .wrapper{
           width: 650px;
           margin:0 auto;
       }
       .page-header h2{
           margin-top:0;
       }
       table tr td:last-child a{
           margin-right:10px;
       }
   </style>
</head>
<body>
<div class="wrapper">
   <div class="container-fluid">
	  <div class="row">
		 <div class="col-md-12">
			<div class="page-header clearfix">
			   <h2 class="pull-left">FPT-APTECH-LIBRARY</h2>
				<!--ko lay duoc gia tri o input :(  -->
			   <input type="text" id="search" >
			   <a href="searchtitle.php?title='#search'"><button
					class="btn btn-success pull-right">Search Title</button></a>
			</div>
			<?php
			   
			   require_once 'includes/config.php';
			   
			   $sql="SELECT * FROM library";
			   if($result =mysqli_query($conn,$sql)){
				  if (mysqli_num_rows($result)>0){
					 echo"<table class='table table-bordered table-striped'>";
					 echo "<thread>";
					 echo "<tr>";
					 echo "<th>BookID</th>";
					 echo "<th>AuthorID</th>";
					 echo "<th>ISBN</th>";
					 echo "<th>Pub_Year</th>";
					 echo "<th>Available</th>";
					 echo "<th>Title</th>";
					 echo "</tr>";
					 echo "</thread>";
					 echo "<tbody>";
					 while($row=mysqli_fetch_array($result)){
						echo "<tr>";
						echo"<td>".$row['bookid']."</td>";
						echo"<td>".$row['authorid']."</td>";
						echo"<td>".$row['ISBN']."</td>";
						echo"<td>".$row['pub_year']."</td>";
						echo"<td>".$row['available']."</td>";
						echo"<td>".$row['title']."</td>";
						echo "</tr>";
					 }
					 echo "</tbody>";
					 echo "</table>";
					 mysqli_free_result($result);
				  }else{
					 echo "<p class='lead'><em>No records were found.</em></p>";
				  }
			   }else{
				  echo "ERROR: Could not able to execute $sql.".mysqli_error($conn);
			   }
			   mysqli_close($conn);
			?>
		 </div>
	  </div>
   </div>
</div>
</body>
</html>

