// Session 2
// Code Snippet1
<?php
// Code Snippet 1
echo "Hello World";
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 2
<?php
// Code Snippet 2
// This is a single-line comment
/* and this is a multi-line comment */
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 3
<?php
// Code Snippet3
echo gmdate("M d Y");
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 4
<?php
// Code Snippet 4
echo "Hello Everybody";
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 5
<?php
// Code Snippet 5
$str = "My name is Samson";
echo $str;
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 6
<?php
// Code Snippet 6
header('WWW-Authenticate: negotiate');
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 7
<?php
// Code Snippet 7
header('WWW-Authenticate: Negotiate');
header('WWW-Authenticate: NTLM', false);
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 8
<?php
// Code Snippet 8
header("Location: http://google.com");
?>
<?php
echo '</br>';
echo '</br>';
?>
// Code Snippet 9
<?php
// Code Snippet 9
header("Location: http://google.com", true, 303);
?>

