<?php
// Code Snippet 7
namespace Day1;
class Boston {
    function say()
    {
        echo "Boston\n";
    }
}
class NewYork{
    function say()
    {
        echo "NewYork\n";
    }
}
function foo1()
{
    echo "This is fool()\n";
}
function foo2()
{
    echo "This is foo2()\n";
}
?>

