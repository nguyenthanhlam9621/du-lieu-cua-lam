#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	float c;
	float f;
	
	printf("Do C can chuyen doi:\n");
	scanf("%f",&c);
	
	printf("Do F Tuong ung:\n %.2f",f=c*9/5+32);

	
	
	return 0;
}
