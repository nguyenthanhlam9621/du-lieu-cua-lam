#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf("*Class:T1104L			*\n");
	printf("*RolNo:B0001			*\n");
	printf("*Full Name:Nguyen Van A		*\n");
	printf("*Email:anv@fpt.aptech.ac.vn	*\n");
	printf("*Phone:0912345678		*\n");
	return 0;
}
